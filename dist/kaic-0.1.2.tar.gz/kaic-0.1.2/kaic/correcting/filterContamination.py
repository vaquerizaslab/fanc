'''
Created on Apr 7, 2015

@author: kkruse1
'''


def filterContamination(samSample, samContaminant, output):
    print "test"